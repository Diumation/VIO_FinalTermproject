function traj = get_traj(log)
traj = log; % alias for consistency with VO naming
end
