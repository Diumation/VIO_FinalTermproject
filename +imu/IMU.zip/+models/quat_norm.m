function n = quat_norm(q)
n = sqrt(sum(q.^2));
end
